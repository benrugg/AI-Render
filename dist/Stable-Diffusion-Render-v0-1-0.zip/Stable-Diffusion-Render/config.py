API_URL = "https://c7vllddffse76obdapr6s2p4du0ydjrn.lambda-url.us-west-2.on.aws/"
DREAM_STUDIO_URL = "http://dreamstudio.ai/"
GETTING_STARTED_URL = "https://www.google.com/" # TODO: MAKE THIS!
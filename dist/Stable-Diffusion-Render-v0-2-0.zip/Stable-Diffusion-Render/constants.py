import bpy
from . import utils

package_name = 'Stable-Diffusion-Render'
default_prompt_text = "Describe anything you can imagine"
valid_dimensions_tuple_list = utils.generate_valid_dimensions_tuple_list()
